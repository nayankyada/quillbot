declare namespace IIcons {
  export interface IconProps {
    width?: string;
    height?: string;
    fillColor?: string;
  }
}

export { IIcons };
